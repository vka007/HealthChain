package com.example.android.login1;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

public class ThirdActivity extends AppCompatActivity {
    private EditText Name1;
    private EditText Password;
    private String username,password3,pass1;
    String aadharno;
    private EditText Password1;
    private EditText Aadhar;
    private Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        Name1 = (EditText) findViewById(R.id.tvName);
        Aadhar = (EditText) findViewById(R.id.tvAadhar);
        Password = (EditText) findViewById(R.id.pass);
        Password1 = (EditText) findViewById(R.id.pass2);
        register = (Button) findViewById(R.id.btregd);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate();}
        });
    }

    private void validate () {
        username = Name1.getText().toString();
        aadharno = Aadhar.getText().toString();
        password3 = Password.getText().toString();
        pass1 = Password1.getText().toString();
        if (password3.equals(pass1) && password3.length() > 0) {
            if (username.length() > 0) {
                if (aadharno.length() == 12) {
                    MessageBox("Successful");
                    Intent intent1 = new Intent(ThirdActivity.this, MainActivity.class);
                    startActivity(intent1);
                } else {
                    MessageBox("Aadhar Number should be of 12 characters long");
                }

            }
            else {
                MessageBox("Name should not be empty.");
            }
        }
        else {
            MessageBox("Password Mismatch. Try Again!");

        }

        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if (success) {
                        Intent intent = new Intent(ThirdActivity.this, MainActivity.class);
                        ThirdActivity.this.startActivity(intent);
                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(ThirdActivity.this);
                        builder.setMessage("Register Failed")
                                .setNegativeButton("Retry", null)
                                .create()
                                .show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        RegisterRequest registerRequest = new RegisterRequest(username,password3,aadharno, responseListener);
        RequestQueue queue = Volley.newRequestQueue(ThirdActivity.this);
        queue.add(registerRequest);
    }

    private void MessageBox(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}



<?php
	$dbservername = "sql304.ultimatefreehost.in";
	$dbusername = "ltm_21811039";
	$dbpassword = "iloveyou21";
	$dbname = "ltm_21811039_login_system";

	$link = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
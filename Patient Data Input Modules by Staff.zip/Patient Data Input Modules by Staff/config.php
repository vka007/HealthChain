<?php
session_start();

	$dbservername = "localhost";
	$dbusername = "root";
	$dbpassword = "";
	$dbname = "login_system";

	$link = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);

$res=$link->query("SELECT * FROM `users`");



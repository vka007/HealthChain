<?php
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;

  
}

    // Include config file
    require_once 'config.php';
 $abc=$_SESSION['username'];
$ress=$link->query("SELECT * FROM users WHERE username='$abc';");
$result=$ress->fetch_object();
 $idd=$result->id;

//$_SESSION['id']



    $aadhaarno = $address = $ph_no = $reg_date = $issue_type = $doctor = $tests = $medis = "";
    $aadhaarno_err = $address_err = $ph_no_err = $reg_date_err = $issue_type_err = $doctor_err = $tests_err = $medis_err = "";

// Processing form data when form is submitted
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        
        //Adhaar
        if(empty(trim($_POST['adhaar']))){
        $adhaar_err = "Please enter your adhaar no. .";     
        } else{
            $adhaar = trim($_POST['adhaar']);
        }

        //Address
        if(empty(trim($_POST['address']))){
        $address_err = "Please enter your address.";     
        } else{
            $address = trim($_POST['address']);
        }

        //Phone no.
        if(empty(trim($_POST['ph_no']))){
        $ph_no_err = "Please enter your Phone no. .";     
        } else{
            $ph_no = trim($_POST['ph_no']);
        }

        //Register Date
        if(empty(trim($_POST['reg_date']))){
        $reg_date_err = "Please enter your Register date.";     
        } else{
            $reg_date = trim($_POST['reg_date']);
        }

        //health issue type
        if(empty(trim($_POST['issue_type']))){
        $issue_type_err = "Please enter your health issue type.";     
        } else{
            $issue_type = trim($_POST['issue_type']);
        }

        //Doctor
        if(empty(trim($_POST['doctor']))){
        $doctor_err = "Please enter your doctor.";     
        } else{
            $doctor = trim($_POST['doctor']);
        }

        //Tests
        $tests = trim($_POST['tests']);

        //Medicines
        if(empty(trim($_POST['medis']))){
        $medis_err = "Please enter your medis.";     
        } else{
            $medis = trim($_POST['medis']);
        }

        // Check input errors before inserting in database
        if(empty($adhaar_err) && empty($address_err) && empty($ph_no_err) && empty($reg_date_err) && empty($issue_type_err) && empty($doctor_err) && empty($tests_err) && empty($medis_err)){
            // Prepare an insert statement
            //$sql = "INSERT INTO users (ADHAAR, Address, Phone No., Registration Dates, Health issue Type, Doctor, Tests, Medicines) VALUES (?, ?, ?, ?, ?, ?) WHERE username='".$_SESSION['username']."' ";
             
            $stmt=$link->query("UPDATE `users` SET `ADHAAR`='$adhaar',`Address`='$address',`Phone No.`='$ph_no',`Registration Dates`='$reg_date',`Health issue Type`='$issue_type',`Doctor`='$doctor',`Tests`='$tests',`Medicines`='$medis' WHERE id='$idd'");


/*            if($stmt = mysqli_prepare($link, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "ssisssss", $param_adhaar, $param_address, $param_ph_no, $param_reg_date, $param_issue_type, $param_doctor, $param_tests, $param_medis);
                
                // Set parameters
                $param_adhaar = $adhaar;
                $param_address = $address;
                $param_ph_no = $ph_no;
                $param_reg_date = $reg_date;
                $param_issue_type = $issue_type;
                $param_doctor = $doctor;
                $param_tests = $tests;
                $param_medis = $medis;*/
                
                // Attempt to execute the prepared statement
                /*if(mysqli_stmt_execute($stmt)){
                    // Redirect to login page
                    header("location: login.php");
                } else{
                    echo "Something went wrong. Please try again later.";
                }*/
            
            // Close statement
            //mysqli_stmt_close($stmt);
        }
        // Close connection
        //mysqli_close($link);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
            body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
        <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION['username']); ?></b>. Welcome to our site.</h1>
    </div>
    <div>
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div>
                Name:&nbsp; <input type="text" value="<?php echo htmlspecialchars($_SESSION['username']); ?>">
            </div>
            <br>
            <div class="form-group <?php echo (!empty($adhaar_err)) ? 'has-error' : ''; ?>">
                <label>Adhaar</label>
                <input type="text" name="adhaar" class="form-control" value="<?php echo $adhaar; ?>">
                <span class="help-block"><?php echo $adhaar_err; ?></span>
            </div>
            <br>
            <div class="form-group <?php echo (!empty($address_err)) ? 'has-error' : ''; ?>">
                <label>Address</label>
                <input type="text" name="address" class="form-control" value="<?php echo $address; ?>">
                <span class="help-block"><?php echo $address_err; ?></span>
            </div>
            <br>
            <div class="form-group <?php echo (!empty($ph_no_err)) ? 'has-error' : ''; ?>">
                <label>Phone no.</label>
                <input type="text" name="ph_no" class="form-control" value="<?php echo $ph_no; ?>">
                <span class="help-block"><?php echo $ph_no_err; ?></span>
            </div>
            <br>
            <div class="form-group <?php echo (!empty($reg_date_err)) ? 'has-error' : ''; ?>">
                <label>Registration Date</label>
                <input type="date" name="reg_date" class="form-control" value="<?php echo $reg_date; ?>">
                <span class="help-block"><?php echo $reg_date_err; ?></span>
            </div>
            <br>
            <div class="form-group <?php echo (!empty($issue_type_err)) ? 'has-error' : ''; ?>">
                <label>Health Issue Type</label>
                <input type="text" name="issue_type" class="form-control" value="<?php echo $issue_type; ?>">
                <span class="help-block"><?php echo $issue_type_err; ?></span>
            </div>
            <br>
            <div class="form-group <?php echo (!empty($doctor_err)) ? 'has-error' : ''; ?>">
                <label>Doctor</label>
                <input type="text" name="doctor" class="form-control" value="<?php echo $doctor; ?>">
                <span class="help-block"><?php echo $doctor_err; ?></span>
            </div>
            <br>
            <div>
                Tests: &nbsp;<input type="text" name="tests">
            </div>
            <br>
            <div class="form-group <?php echo (!empty($medis_err)) ? 'has-error' : ''; ?>">
                <label>Medicines</label>
                <input type="text" name="medis" class="form-control" value="<?php echo $medis; ?>">
                <span class="help-block"><?php echo $medis_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
        </form>
    </div>
    <p><a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a></p>
</body>
</html>